NYX WEBSITE 🎀🖤

FILES:
- index.html
- style.css
- script.js

EASIEST WAY TO PUT IT ONLINE WITH YOUR EXISTING GITHUB PAGES:

1. Open your GitHub repository:
   nyxops / nyx-bot

2. Upload these three files into the MAIN/root of the repository:
   index.html
   style.css
   script.js

3. Keep your existing:
   terms.html
   privacy.html

4. GitHub Pages should then show Nyx's homepage at:
   https://nyxops.github.io/nyx-bot/

The website already links to:
- Night Stalkers Unit Discord invite
- Terms
- Privacy
- Partnership channel

NOTE:
The Nyx portrait area is currently a stylized placeholder.
You can replace it later with Nyx's actual artwork.
