NYX WEBSITE — ARTWORK UPDATE 🎀🖤

This keeps the ORIGINAL website design and writing.
The only major change is that Nyx's artwork has been added to the hero card.

Upload/replace these files in the root of your GitHub nyx-bot repo:
- index.html
- style.css
- script.js
- nyx-artwork.png

Your existing terms.html and privacy.html can stay as they are.
